/*
NLP Assignment 
Group 10
Group Members:  Vardhan, Khushal , Pranshul 
*/

// test: some specific keywords
//#include <stdio.h>
int main(){
    printf("HELLO WORLD\n");
}